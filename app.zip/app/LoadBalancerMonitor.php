<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LoadBalancerMonitor extends Model
{
    //
}
